﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio12
{
    internal class MarkdownFormatter : ContatoFormatter
        {
            public override void ExibirContatos(List<Contato> contatos)
            {
                
                Console.WriteLine("Lista de Contatos (Markdown)");
                foreach (var contato in contatos)
                {
                    Console.WriteLine("----------------------------------");
                    Console.WriteLine($"- **Nome: ** {contato._nome} ");
                    Console.WriteLine($"- 📞 Telefone: ** {contato._telefone}");
                    Console.WriteLine($"- 📧 Email: ** {contato._email} ");  
                    Console.WriteLine("----------------------------------");
                }
            }
        }
}
