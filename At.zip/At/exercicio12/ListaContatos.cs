﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using exercicio12;

namespace exercicio12
{
    public class ListaContatos
    {
        private  String _caminhoArquivo;
        private List<Contato> ListaUsuario = new List<Contato>();


        public ListaContatos(String caminhoArquivo)
        {
            _caminhoArquivo = caminhoArquivo;

            CarregarUsuarios();
        }

        public void AdicionarUsuario( Contato  contato)
        {
            ListaUsuario.Add(contato);

            using (var fluxoArquivo = new StreamWriter(_caminhoArquivo, true))
            {
                fluxoArquivo.WriteLine($"{contato._nome},{contato._telefone},{contato._email}");
            }

        }

        public void ListarUsuarios()
        {

            if (ListaUsuario.Count == 0)
            {
                Console.WriteLine("Nenhum usuário cadastrado.");
                return;
            }

            Console.WriteLine("Selecione o formato de exibição:");
            Console.WriteLine("1 - Markdown");
            Console.WriteLine("2 - Tabela");
            Console.WriteLine("3 - Texto Simples");
            Console.Write("Opção: ");

            int opcao = int.Parse(Console.ReadLine());


            ContatoFormatter formatter;

            switch (opcao)
            {
                case 1:
                    formatter = new MarkdownFormatter();
                    break;
                case 2:
                    formatter = new TabelaFormatter();
                    break;
                case 3:
                    formatter = new RawTextFormatter();
                    break;
                default:
                    formatter = new RawTextFormatter();
                    break;
            }

            formatter.ExibirContatos(ListaUsuario);
        }

        private void CarregarUsuarios()
        {
            
            if (!File.Exists(_caminhoArquivo) || new FileInfo(_caminhoArquivo).Length == 0 )
            {
                
                Console.WriteLine("Nenhum usuário cadastrado.");
                return;
            }

                using (var fluxoArquivo = new StreamReader(_caminhoArquivo))
                {
                    while (!fluxoArquivo.EndOfStream)
                    {
                        string linha = fluxoArquivo.ReadLine();
                        string[] campos = linha.Split(',');

                        Contato contato = new Contato(campos[0], campos[1], campos[2]);
                        ListaUsuario.Add(contato);
                    }
                }
            }
        }
    }
