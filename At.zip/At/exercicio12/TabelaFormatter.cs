﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio12
{
    internal class TabelaFormatter : ContatoFormatter
    {
        public override void ExibirContatos(List<Contato> contatos)
        {
            Console.WriteLine("Lista de Contatos (Tabela)");
            Console.WriteLine("--------------------------------------------------------");
            Console.WriteLine("| Nome                 | Telefone   | Email                |");
            Console.WriteLine("--------------------------------------------------------+");

            foreach (var contato in contatos)
            {
                Console.WriteLine($"| {contato._nome,-20} | {contato._telefone,-10} | {contato._email,-20} |");
                Console.WriteLine("--------------------------------------------------------");
            }
        }
    }
}
