﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio12
{
    public class Contato
    {
        public string _nome { get; set; }
        public string _telefone { get; set; }
        public string _email { get; set; }
    
        public Contato (string  nome, string telefone, string email)
        {
            _nome = nome;

            _telefone = telefone;

            _email = email;
        }


        public override string ToString()
        {
            return $"Nome: {_nome} | Telefone: {_telefone} | Email: {_email}";
        }



    }
}
