﻿
using System.Text;
using exercicio12;

class Program
{

    static void Main()
    {

        // aqui e para os emojis funcionarem no console
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        ListaContatos listaContatos = new ListaContatos("contatos.txt");




        while (true)
        {
            Console.WriteLine("Menu de Opções:");
            Console.WriteLine("1 - cadastrar novo contato");
            Console.WriteLine("2 - Lista contatos");
            Console.WriteLine("3 - Sair");
            Console.Write("opção: ");

            int opcao = int.Parse(Console.ReadLine());


            switch (opcao)
            {
                case 1:
                    Console.Write("Nome do Usuário: ");
                    string nome = Console.ReadLine();

                    Console.Write("Telefone: ");
                    string telefone = Console.ReadLine();

                    Console.Write("Email: ");
                    string email = Console.ReadLine();

                    Contato contato = new Contato(nome, telefone, email);

                    listaContatos.AdicionarUsuario(contato);

                    Console.WriteLine("Contato cadastrado com sucesso!");
                    break;
                case 2:
                    listaContatos.ListarUsuarios();
                    break;
                case 3:
                    return;
                default:
                    Console.WriteLine("Opção inválida. Tente novamente.");
                    break;
            }
        }
    }
}


