﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio12
{
    internal class RawTextFormatter : ContatoFormatter
    {
        public override void ExibirContatos(List<Contato> contatos)
        {
            Console.WriteLine("Lista de Contatos (Texto Simples)");
            foreach (var contato in contatos)
            {
                Console.WriteLine($"Nome: {contato._nome} | Telefone: {contato._telefone} | Email: {contato._email}");
               
            }
        }
    }
}
