﻿class Program
{
    static void Main(String[] args)
    {
        DateTime dataAtual = DateTime.Now;
        DateTime dataFormatura = new DateTime(2026, 12, 15);


        Console.WriteLine("Digite sua data atual: ");
        dataAtual = DateTime.Parse(Console.ReadLine());

        

        int diasParaFormatura = dataFormatura.Day - dataAtual.Day;
        int mesesParaFormatura = dataFormatura.Month - dataAtual.Month;
        int anosParaFormatura = dataFormatura.Year - dataAtual.Year;



        if (dataAtual.Year > dataFormatura.Year)
        {
            Console.WriteLine("Erro: A data informada não pode ser no futuro!");
            return;
        }
        
         if (dataAtual >= dataFormatura)
        {
            Console.WriteLine("A formatura já passou! Parabéns!");
            return;
        }

         

        if (anosParaFormatura == 0 & mesesParaFormatura <= 5 & diasParaFormatura <= 10)
        {
            Console.WriteLine($"Faltam {anosParaFormatura} anos, {mesesParaFormatura} meses e {diasParaFormatura} dias para sua formatura!");
            Console.WriteLine($"A reta final chegou! Prepare-se para a formatura!");

        }

        else
        {
            Console.WriteLine($"Faltam {anosParaFormatura} anos, {mesesParaFormatura} meses e {diasParaFormatura} dias para sua formatura!");

        }
        Console.ReadKey();

    }
 

}
