﻿


class program
{
    static void Main()
    {

        DateTime dataNascimento;

        String nome = "Lucas";
        Console.WriteLine($"Ola, meu nome é {nome}");
        dataNascimento = new DateTime(2003, 10, 12);
        Console.WriteLine($"Nasci em {dataNascimento} e estou aprendendo C#!");
    }
    }