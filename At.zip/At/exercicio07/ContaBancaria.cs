﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio07
{
    public class ContaBancaria
    {
        public String Titular { get; set; }

        private double _saldo;


        public ContaBancaria()
        {
           
        }

        public double Depositar(double valor)
        {
            if(valor > 0)
            {
                _saldo += valor;
                Console.WriteLine($"Depósito de R$ {valor} realizado com secesso!");
            }

            else
            {
                Console.WriteLine("Valor invalido");
               
            }
            return _saldo;    
           
        }


        public double Sacar(double valor)
        {
            if (valor > 0)
            {
                if (_saldo >= valor)
                {
                    _saldo -= valor;
                    Console.WriteLine($"Saque de R$ {valor} realizado com sucesso");
                   
                }
                else
                {
                    Console.WriteLine($"Tentativa de saque de R$ {valor}");
                    Console.WriteLine("Saldo insuficiente para realizar o saque!");
                }
            }
            else
            {
                Console.WriteLine("Valor invalido");
            }
            return _saldo;
        }


        public void ExibirSaldo()
        {
            Console.WriteLine($"seu saldo atual é:  R$ {_saldo}");
        }


    }
}
