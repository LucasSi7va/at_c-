﻿using exercicio07;

class Program
{
    static void Main()
    {
        ContaBancaria conta = new ContaBancaria();

        Console.WriteLine($"Titular: {conta.Titular = "João Silva"} ");     ;

        conta.Depositar(500);

        conta.ExibirSaldo();

        conta.Sacar(700);

        conta.Sacar(200);

        conta.ExibirSaldo();

    }
}
