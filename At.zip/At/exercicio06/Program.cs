﻿using exercicio06;

class Program
{
    static void Main(string[] args)
    {
        Aluno aluno = new Aluno("lucas", 123213, "infnet", 5);

        aluno.ExibirDados();

        Console.WriteLine($"Resultado: {aluno.VerificarAprovacao()}");

    }
}