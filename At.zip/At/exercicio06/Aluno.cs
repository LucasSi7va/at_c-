﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio06
{
    public class Aluno
    {
        public String _nome { get; set; }
        public int _matricula { get; set; }
        public String _curso { get; set; }
        public float _notas { get; set; }



        public Aluno(String nome, int matricula, string curso, float notas)
        {
            _nome = nome;
            _matricula = matricula;
            _curso = curso;
            _notas = notas;
        }

        public string VerificarAprovacao()
        {
            if (_notas >= 7)
            {
                return "Aprovado";
            }
            else
            {
                return "Reprovado";
            }


        }


        public void ExibirDados()
        {
            Console.WriteLine("/=========================================/");
            Console.WriteLine("Dados do aluno");
            Console.WriteLine($"Nome: {_nome}");
            Console.WriteLine($"Matricula: {_matricula}");
            Console.WriteLine($"Curso: {_curso}");
            Console.WriteLine($"Media do aluno: {_notas}");
            Console.WriteLine("/=========================================/");
        }




    }


}
