﻿class program
{
    static void Main()
    {
        Console.WriteLine("Digite o numero da opcao desejada: ");
        Console.WriteLine("1 - +");
        Console.WriteLine("2 - -");
        Console.WriteLine("3 - *");
        Console.WriteLine("4 - /");

        int opcao = int.Parse(Console.ReadLine());

        Console.WriteLine("Digite o primeiro numero: ");
        float num1 = float.Parse(Console.ReadLine());

        Console.WriteLine("Digite o segundo numero: ");
        float num2 = float.Parse(Console.ReadLine());



        switch (opcao)
        {
            case 1:

                Console.WriteLine($"O resultado da soma é {num1 + num2}");
                break;


            case 2:
                Console.WriteLine($"O resultado da subtração é {num1 - num2}");
                break;


            case 3:
                Console.WriteLine($"O resultado da multiplicação é {num1 * num2}");
                break;

            case 4:
                if(num1 == 0 || num2 == 0)
                {
                    Console.WriteLine("Não é possível dividir por zero");
                }
                else
                {
                    Console.WriteLine($"O resultado da divisão é {num1 / num2}");
                }
                break;

            default:
                {
                    Console.WriteLine("Opção inválida");
                    break;
                }

        }


    }
}