﻿using System;
using Exercicio08;

class Program
{
    static void Main()
    {
        // Criando um funcionário comum
        Console.WriteLine("Cadastro de Funcionário");
        Console.Write("Digite o nome: ");
        string nomeFuncionario = Console.ReadLine();

        Console.Write("Digite o cargo: ");
        string cargo = Console.ReadLine();

        Console.Write("Digite o salário: ");
        double salario = double.Parse(Console.ReadLine());

        Console.WriteLine("/==============================/");

        if (cargo.ToLower() == "gerente")
        {
            Gerente gerente = new Gerente(nomeFuncionario, salario);
            gerente.ExibirSalario();
        }
        else
        {
            Funcionario funcionario = new Funcionario
            {
                Nome = nomeFuncionario,
                Cargo = cargo,
                SalarioBase = salario
            };
            funcionario.ExibirSalario();
        }

        Console.WriteLine("/==============================/");
    }
}
