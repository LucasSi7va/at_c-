﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio08
{
    public class Funcionario
    {
        public String Nome { get; set; }
        
        public String Cargo { get; set; }

        public double SalarioBase { get; set; }

        public virtual void ExibirSalario()
        {
            Console.WriteLine($"Nome: {Nome}");
            Console.WriteLine($"Cargo: {Cargo}");
            Console.WriteLine($"Salario: {SalarioBase}");
        }

    }

    public class Gerente : Funcionario
    {
        public Gerente(string nome, double salarioBase)
        {
            Nome = nome;
            Cargo = "Gerente";
            SalarioBase = salarioBase;
        }

        public override void ExibirSalario()
        {
            double bonus = SalarioBase * 0.2;
            Console.WriteLine($"Nome: {Nome}");
            Console.WriteLine($"Cargo: {Cargo}");
            Console.WriteLine($"voce recebeu um bonus de: {bonus}");
            Console.WriteLine($"Salario: R${SalarioBase + bonus}");



        }

    }

}

