﻿using System;
using System.Collections.Generic;
using System.IO;
using exercicio11;

namespace exericio11
{
    public class ListagemContato
    {
        private string _caminhoArquivo;
        private List<Usuario> usuarios;
      

        public ListagemContato(string caminhoArquivo)
        {
            _caminhoArquivo = caminhoArquivo;
            usuarios = new List<Usuario>();
        }

        public void AdicionarUsuario(Usuario usuario)
        {


            using (var fluxoArquivo = new StreamWriter(_caminhoArquivo, true))
            {
                fluxoArquivo.WriteLine($"{usuario._nome};{usuario._telefone};{usuario._email}");
            }
        }

        public List<Usuario> ListarUsuarios()
        {
            usuarios.Clear();


            if (!File.Exists(_caminhoArquivo)  || new FileInfo(_caminhoArquivo).Length == 0)
            {
                Console.WriteLine("Nenhum usuario cadastrado");
                return usuarios;
            }

            using (var fluxoArquivo = new StreamReader(_caminhoArquivo))
            {
                string linha;
                while ((linha = fluxoArquivo.ReadLine()) != null)
                {
                    var dadosUsuario = linha.Split(';');

                    var usuario = new Usuario(dadosUsuario[0], int.Parse(dadosUsuario[1]), dadosUsuario[2]);

                    usuarios.Add(usuario);
                }
            }

            return usuarios;
        }
    }
}
