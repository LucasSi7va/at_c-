﻿using exercicio11;
using exericio11;

class Program
{
  
        static void Main()
        {
           ListagemContato caminhoArquivo = new ListagemContato("contatos.txt");

        while (true)
            {
                Console.WriteLine("Menu de Opções:");
                Console.WriteLine("1 - Inserir usuario");
                Console.WriteLine("2 - Lista usuario");
                Console.WriteLine("3 - Sair");
                Console.Write("Escolha uma opção: ");
                string opcao = Console.ReadLine();

                switch (opcao)
                {
                    case "1":

                    Console.WriteLine("Digite o nome: ");
                    string nome = Console.ReadLine();

                    Console.WriteLine("Digite a telefone: ");
                    int telefone = int.Parse(Console.ReadLine());

                    Console.WriteLine("Digite o email: ");
                    string email = Console.ReadLine();

                    Usuario contato = new Usuario(nome, telefone , email);

                    caminhoArquivo.AdicionarUsuario(contato);

                    Console.WriteLine("Contato cadastrado com sucesso!");
                    break;

                    case "2":
                    
                    List<Usuario> usuario = caminhoArquivo.ListarUsuarios();

                    foreach (var item in usuario)
                    {
                        Console.WriteLine($"Nome: {item._nome} ||  telefone: {item._telefone} || email: {item._email}");
                    }
                    Console.WriteLine("-------------------------------------------------");
                    break;

                    
                case "3":
                    Console.WriteLine("Encerrando Programa...");
                    return;

                    default:
                        Console.WriteLine("Opção inválida. Tente novamente.");
                        break;
                }
            }
        }
    }

