﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercicio11
{
    public class Usuario
    {
        public String _nome { get; set; }

        public int _telefone { get; set; }

        public String _email { get; set; }

        public Usuario(string nome, int telefone, string email)
        {
            _nome = nome;
            _telefone = telefone;
            _email = email;
        }


    }
}
