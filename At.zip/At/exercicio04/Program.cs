﻿using System.Diagnostics;

class program
{
    static void Main()
    {
        DateTime dataNascimento;
        DateTime dataAtual = DateTime.Now;
        DateTime proximoAniversario;

        Console.WriteLine("Digite sua data de nascimento: ");
        dataNascimento = DateTime.Parse(Console.ReadLine());



        proximoAniversario = new DateTime(dataAtual.Year, dataNascimento.Month, dataNascimento.Day);

        
        if (proximoAniversario < dataAtual)
        {
            proximoAniversario = proximoAniversario.AddYears(1);
        }


        TimeSpan diasDoAniversario = proximoAniversario - dataAtual;

        if (diasDoAniversario.Days <= 7)
        {
            Console.WriteLine($"falta {diasDoAniversario.Days} dia para seu aniversario se atente!");
        }

        else
        {
            Console.WriteLine($"falta  {diasDoAniversario.Days} dia para seu aniversario");

        }
    }
}