﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aluno
{
    public class CadastroAlunoArquivo
    {
        private string _caminhoArquivo;
        private List<Aluno> _lstAluno;

        public CadastroAlunoArquivo(string caminhoArquivo)
        {
            _caminhoArquivo = caminhoArquivo;
            _lstAluno = new List<Aluno>();
        }


        public void AdicionarAluno(Aluno aluno)
        {

            using (var fluxoArquivo = new StreamWriter(_caminhoArquivo, true))
            {


                //fluxoArquivo.WriteLine($"{i} - {conteudo}");        }
                fluxoArquivo.WriteLine($"{aluno.Nome} , {aluno.Idade}");
            }
        }

        public List<Aluno> ListarAlunos()
        {
            using (var fluxoArquivo = new StreamReader(_caminhoArquivo))
            {
                while (fluxoArquivo.EndOfStream)
                {
                    string linha = fluxoArquivo.ReadLine();


                    String[] campos = linha.Split(";");

                    Aluno alunoLido = new Aluno(campos[0], short.Parse(campos[1]));
                    _lstAluno.Add(alunoLido);
                }



            }

            return _lstAluno;
        }


    }
}
