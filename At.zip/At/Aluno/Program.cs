﻿using Aluno;

public class Program
{
    public static void Main()
    {
        Aluno aluno1 = new("Alex", 23);
        Aluno aluno2 = new("gta", 20);
        Aluno aluno3 = new("luis", 30);

        // CadastroAlunoMemoria alunoMemoria = new();

        // alunoMemoria.AdicionarAluno(aluno1);

        //  alunoMemoria.ListarAlunos();

        CadastroAlunoArquivo alunoArquivo = new("Aluno.txt");



        alunoArquivo.AdicionarAluno(aluno1);
        alunoArquivo.AdicionarAluno(aluno2);
        alunoArquivo.AdicionarAluno(aluno3);

        foreach (var aluno in alunoArquivo.ListarAlunos())
        {
            Console.WriteLine(aluno.ToString());
        }


        //for(int i = 0; i < alunoArquivo.ListarAlunos() .Count-1; i++)
        //{

        //}



        Console.ReadLine();
    }

}