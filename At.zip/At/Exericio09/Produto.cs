﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exericio09
{
  public class Produto
    {
        public string _nome { get; set; }
        public int _quantidade { get; set; }
        public decimal _preco { get; set; }

        public Produto(string nome, int quantidade, decimal preco)
        {
            _nome = nome;
            _quantidade = quantidade;
            _preco = preco;
        }

    }
}
