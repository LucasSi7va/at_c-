﻿using Exericio09;

class Program
{
    static void Main()
    {
        GerenciadorEstoque caminhoArquivo = new GerenciadorEstoque("estoque.txt");
        


        while (true)
        {


        Console.WriteLine("Menu de Opções:");
        Console.WriteLine("1 - Adicionar produto");
        Console.WriteLine("2 - Listar produtos");
        Console.WriteLine("3 - Sair");

        int opcao = int.Parse(Console.ReadLine());

            switch (opcao)
            {
                case 1:
                    Console.WriteLine("Digite o nome do produto:");
                    string nome = Console.ReadLine();

                    Console.WriteLine("Digite a quantidade do produto:");
                    int quantidade = int.Parse(Console.ReadLine());

                    Console.WriteLine("Digite o preço do produto:");
                    decimal preco = decimal.Parse(Console.ReadLine());

                    Produto produto = new Produto(nome, quantidade, preco);

                    caminhoArquivo.AdicionarProduto(produto);
                    break;

                case 2:
                    List<Produto> produtos = caminhoArquivo.ListaProduto();
                    foreach (var item in produtos)
                    {
                        Console.WriteLine($"Nome: {item._nome}, Quantidade: {item._quantidade}, Preço: {item._preco}");
                    }
                    Console.WriteLine("-------------------------------------------------");
                    break;

                case 3:
                    Console.WriteLine("Encerrando Programa...");
                    return;
               
                default:
                    Console.WriteLine("Opção inválida. Tente novamente.");
                    break;
            }

        }

    }

}