﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exericio09
{
    public class GerenciadorEstoque
    {
        private String _caminhoArquivo;
        private List<Produto> produtos;
        public int limite = 5;


        public GerenciadorEstoque(string caminhoArquivo)
        {
            _caminhoArquivo = caminhoArquivo;
            produtos = new List<Produto>();
        }


        public void AdicionarProduto(Produto produto)
        {

            ListaProduto();

            if (produtos.Count >= limite)
            {
                Console.WriteLine("Limite de produtos atingido.");
                return;
            }

            using (var fluxoArquivo = new StreamWriter(_caminhoArquivo, true))
            {
                fluxoArquivo.WriteLine($"{produto._nome};{produto._quantidade};{produto._preco}");
            }

        }


        public List<Produto> ListaProduto()
        {
            produtos.Clear();

            if( !File.Exists(_caminhoArquivo)  || new FileInfo(_caminhoArquivo).Length == 0)
            {
                Console.WriteLine("Nenhum produto cadastrad");
                return produtos;
            }


            using (var fluxoArquivo = new StreamReader(_caminhoArquivo))
            {
                string linha;
                while ((linha = fluxoArquivo.ReadLine()) != null)
                {
                    var dadosProduto = linha.Split(';');

                    var produto = new Produto(dadosProduto[0], int.Parse(dadosProduto[1]), decimal.Parse(dadosProduto[2]));

                    produtos.Add(produto);
                }
            }



            return produtos;


        }

    }
}