﻿using System;

class Program
{
    static void Main()
    {
        Random random = new Random();
        int numeroSecreto = random.Next(1, 51); 
        int tentativas = 5;

        Console.WriteLine("Tente adivinhar o número entre 1 e 50!");

        while (tentativas > 0)
        {
            Console.Write($"Você tem {tentativas} tentativas. Digite um número: ");

            try
            {
                int palpite = int.Parse(Console.ReadLine());

                if (palpite < 1 || palpite > 50)
                {
                    Console.WriteLine("Erro: O número deve estar entre 1 e 50.");
                    continue;
                }

                if (palpite == numeroSecreto)
                {
                    Console.WriteLine("Parabéns! Você acertou!");
                    return;
                }
                else if (palpite < numeroSecreto)
                {
                    Console.WriteLine("O número é maior!");
                }
                else
                {
                    Console.WriteLine("O número é menor!");
                }

                tentativas--;
            }
            catch (FormatException)
            {
                Console.WriteLine("Erro: Entrada inválida! Digite um número válido.");
            }
        }

        Console.WriteLine($"Fim de jogo! O número correto era {numeroSecreto}.");
    }
}
