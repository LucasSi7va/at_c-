﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Digite seu nome:");
        String nome = Console.ReadLine();
        string resultado = DeslocaNome(nome , 3);

        Console.WriteLine($"Seu nome deslocado é {resultado}");

    }



    static String DeslocaNome(String letra, int deslocamento)
    {
        String resultado = "";

        foreach (char a in letra)

        {
            if (char.IsLetter(a))
            {
                char baseLetra = char.IsUpper(a) ? 'A' : 'a';
                

                char letraDeslocada = (char)(baseLetra + ((a + deslocamento - baseLetra) % 26));
                resultado += letraDeslocada;
            }

            else
            {
                resultado += a;
            }

        }
            return resultado;
        
    }
}
    